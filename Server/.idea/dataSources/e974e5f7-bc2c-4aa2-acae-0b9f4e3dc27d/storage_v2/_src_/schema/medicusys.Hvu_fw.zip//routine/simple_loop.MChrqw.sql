create procedure simple_loop()
  BEGIN
  DECLARE counter BIGINT DEFAULT 0;

  my_loop: LOOP
    SET counter=counter+1;

    IF counter=100000 THEN
      LEAVE my_loop;
    END IF;

    SELECT counter; #uncomment if you'd like to print the counter
	INSERT INTO `visits` (`doctor_id`, `patient_id`, `visit_date`, `visited`) VALUES ('1', '1', '2019-06-02 00:00:00', '0');

  END LOOP my_loop;
END;

